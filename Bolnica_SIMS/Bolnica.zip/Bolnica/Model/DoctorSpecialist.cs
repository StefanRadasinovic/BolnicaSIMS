// File:    DoctorSpecialist.cs
// Author:  User
// Created: Wednesday, April 13, 2022 1:18:00 PM
// Purpose: Definition of Class DoctorSpecialist

using System;

namespace Model
{
   public class DoctorSpecialist : DoctorID
   {
      //private Specialisation specialisation;
   
   }
}