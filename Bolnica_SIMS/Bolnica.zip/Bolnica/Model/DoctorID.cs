// File:    DoctorID.cs
// Author:  User
// Created: Tuesday, April 5, 2022 5:55:22 PM
// Purpose: Definition of Class DoctorID

using System;

namespace Model
{
   public class DoctorID : User
   {
      public int DoctorsID { get; set; }  
     
   
   }
}