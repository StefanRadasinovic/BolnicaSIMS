// File:    Wpf.cs
// Author:  ANA
// Created: Tuesday, April 5, 2022 8:25:13 PM
// Purpose: Definition of Class Wpf

using System;

namespace Model
{
   public class Wpf
   {
      public WpfViewModel wpfViewModel;
   
   }
}