// File:    Adress.cs
// Author:  user
// Created: Friday, April 8, 2022 7:36:16 PM
// Purpose: Definition of Class Adress

using System;

namespace Model
{
   public class Adress
   {
      private String streetNum;
      private String city;
      private String country;
   
   }
}