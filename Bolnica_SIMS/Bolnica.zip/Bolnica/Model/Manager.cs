// File:    Manager.cs
// Author:  User
// Created: Thursday, April 7, 2022 2:40:23 PM
// Purpose: Definition of Class Manager

using System;

namespace Model
{
   public class Manager : User
   {
   }
}