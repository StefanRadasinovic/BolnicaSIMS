// File:    Secretary.cs
// Author:  User
// Created: Thursday, April 7, 2022 2:40:22 PM
// Purpose: Definition of Class Secretary

using System;

namespace Model
{
   public class Secretary : User
   {
   }
}