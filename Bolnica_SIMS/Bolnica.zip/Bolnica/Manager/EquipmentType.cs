﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bolnica.Manager
{
    public enum EquipmentType
    {
        bed,
        desk,
        office_equipment,
        surgery_desk

    }
}
