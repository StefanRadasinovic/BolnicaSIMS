﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bolnica.Manager
{
    internal enum EqTypeID
    {
       A1,
       A2,
       A3,
       A4,
       A5
    }
}
